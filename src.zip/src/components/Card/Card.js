function getCategories(categories) {
  const arr = [];
  let index = 0;

  for (const category of categories) {
    const categoryId = category.id;
    const categoryName = category.name;
    index++;
    arr.push(
      <ul className="category-details">
        <li className="category-list-item"><span>Category ID: </span>{categoryId}</li>
        <li className="category-list-item"><span>Category name: </span>{categoryName}</li>
      </ul>
    );
  }
  return arr;
}


function Card(props) {
  return (
    <div className={`card-container $this.props.display?:'itemShow':'itemHide' `} key={props.ID}>
      <h2>{props.title}</h2>

      <div className='field'>
        <caption>ID</caption>
        <p>{props.id}</p>
      </div>

      <div className='field'>
        <caption>Publish Date</caption>
        <p>{props.publishDate}</p>
      </div>

      <div className="field">
        <caption>Author</caption>
        <div className="author-content">
          <img className="author-avatar" src={props.author.avatar} />
          <p className="author-name"> {props.author.name} </p>
        </div>
      </div>

      <div className='field'>
        <caption>Summary</caption>
        <p>{props.summary}</p>
      </div>

      <div className='field' id='categories'>
        <caption>Categories</caption>
        <div className='category'>
          {getCategories(props.categories)}</div>
      </div>

    </div>
  )
}

export default Card