import React, { useEffect, useState } from "react";
import Card from './Card/Card';
import Select from './Select/Select';
import './Card/Card.scss';  
import './Select/Select.scss';  

const App: React.FC = () => {
  const step = 6;
  const defaultOptions = [
    'Surveys and Forms',
    'Digital Marketing',
    'Platform News and Updates',
    'Tips and Best Practise',
    'Data Management',
    'Marketing Analytics',
    'Landing Pages',
    'Ecommerce',
    'Email Marketing',
    'Marketing Automation'
  ]

  const [posts, setPosts] = useState<any[]>([]);
  const [visible, setVisible] = useState(step);
  const [selectedOptions, setSelectedOptions] = useState(defaultOptions);

  useEffect(() => {
    fetch('api/posts')
      .then(res => res.json())
      .then(json => setPosts(json.posts))
      .catch(err => console.log(err))
  }, [])


  const onShowMore = () => {
    if (visible < posts.length) {
      setVisible((visible) => visible + step);
    }
  }


  // function findUniqueCategories(){
  //   const allCategories = [];
  //   //categories = allCategories;
  //   for (const post of posts) {
  //     for (const category of post.categories)
  //     allCategories.push(category.name);
  //   }
  //   console.log('all categories: ' + allCategories);
  //   const uniqueCategories = Array.from( new Set( allCategories ) );
  //   console.log('unique categories: ' + uniqueCategories);
  // }


  function onFilterValueSelected(filterValue: any) {
    if(filterValue.length>0){
      setSelectedOptions(selectedOptions => filterValue);
    }else{
      setSelectedOptions(selectedOptions => defaultOptions);
    }
  }

  return (
    <div>
      <h1 className="page-title">Posts</h1>
      <div className="filter-options">
      <Select filterValueSelected={onFilterValueSelected}
          label="Filter category"
          placeholder="Pick category"
          options={[
            { value: 'Surveys and Forms' },
            { value: 'Digital Marketing' },
            { value: 'Platform News and Updates' },
            { value: 'Tips and Best Practise' },
            { value: 'Data Management' },
            { value: 'Marketing Analytics' },
            { value: 'Landing Pages' },
            { value: 'Ecommerce' },
            { value: 'Email Marketing' },
            { value: 'Marketing Automation' }
          ]}
          multiple
        />
      </div>
      <div className='wrapper'>
        {posts?.length > 0 ? (
           posts.filter(post => post.categories.filter( (e: { name: string; }) => selectedOptions.includes(e.name)).length > 0)
          .slice(0,visible).map(({ id, title, publishDate, author, summary, categories }) => (
            <Card key={id}
              id={id}
              title={title}
              publishDate={publishDate}
              author={author}
              summary={summary}
              categories={categories}
            />
          ))
        ) : (
          <p>No posts</p>
        )}
      </div>
      <div className = 'btn-wrapper'>
      {visible < posts.length ? <button onClick={onShowMore}>Show more</button> : <p>End of list.</p>}
      </div>
    </div>
  );
};

export default App;
